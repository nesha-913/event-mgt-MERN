import express from "express";
import { PORT, mongoDBURL } from "./config.js";
import mongoose from 'mongoose';
import eventsssRoute from './routes/eventsssRoute.js';
import cors from 'cors'; 
import path from 'path'; // For handling file directories
import { fileURLToPath } from 'url'; // For handling file uploads

//Get directory name from URL
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// server.js or app.js



const app = express();

//middleware for parsing request body
app.use(express.json());

//Middleware for handling CORS POLICY
//Option 1: Allow all origins with Default of cors(*)
app.use(cors());
//Option 2: Allow custom origins
//app.use(
// cors({
//   origin: 'http://localhost:3000',
//    methods: ['GET', 'POST', 'PUT', 'DELETE'],
//      allowedHeaders: ['Content-Type']
//  })
//);

// Serve static files from the 'uploads' directory
//app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/uploads', express.static('uploads'));
// server.js or app.js



// server.js or app.js

 
app.get('/', (request,response) => {
    console.log(request)
    return response.status(234).send('welcome mern stack')
 });

app.use('/events', eventsssRoute);
mongoose
  .connect(mongoDBURL)
  .then(() => {
    console.log('App connected to database');
    app.listen(PORT, () => {
      console.log(`App is listening to port: ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(error);
  });
