export const PORT =5555;

export const mongoDBURL = 
//'mongodb+srv://neshaninavodya640:GNAevent@eventmgt.kv9rc.mongodb.net/event-collection?retryWrites=true&w=majority&appName=eventmgt'

//'mongodb+srv://neshaninavodya640:GNevent@eventmgt.kv9rc.mongodb.net/event-collection?retryWrites=true&w=majority&appName=eventmgt'
'mongodb+srv://neshaninavodya640:GNevent@eventmgt.kv9rc.mongodb.net/event-collection?retryWrites=true&w=majority&appName=eventmgt'

