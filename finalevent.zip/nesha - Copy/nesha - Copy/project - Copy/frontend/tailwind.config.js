/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",               // Correct path to your HTML file
    "./src/**/*.{js,ts,jsx,tsx}",  // Correct path to your JS/TS/JSX/TSX files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}


