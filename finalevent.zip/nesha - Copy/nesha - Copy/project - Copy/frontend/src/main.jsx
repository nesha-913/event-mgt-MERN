import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // Adjust the extension if necessary
import './index.css';
import { BrowserRouter } from 'react-router-dom';

// Ensure that React.StrictMode is used only once and wrapping the BrowserRouter is correct
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
