import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/EventManagement/Home'; // Fixed typo: EventManagenent to EventManagement
import CreateEvents from './pages/EventManagement/CreateEvents'; // Fixed typo
import ShowEvent from './pages/EventManagement/ShowEvent'; // Fixed typo
import EditEvent from './pages/EventManagement/EditEvent'; // Fixed typo
import DeleteEvent from './pages/EventManagement/DeleteEvents'; // Fixed typo
import AboutUs from './pages/aboutUs';
import EventDetailsPage from './pages/EventDetailsPage'; 
import EventCardPage from './pages/EventsCardPage';
import SculpturesPage from './pages/SculpturesPage';
import FurniturePage from './pages/FurniturePage';
import MasksPage from './pages/MasksPage';


const App = () => {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/events/create' element={<CreateEvents />} />
      <Route path='/events/details/:id' element={<ShowEvent />} />
      <Route path='/events/edit/:id' element={<EditEvent />} />
      <Route path='/events/delete/:id' element={<DeleteEvent />} />
      <Route path='/about' element={<AboutUs />} />
      <Route path='/event-details/:id' element={<EventDetailsPage />} /> 
      <Route path='/events/card' element={<EventCardPage />} />
      <Route path='/events/sculptures' element={<SculpturesPage />} />
      <Route path='/events/furniture' element={<FurniturePage />} />
      <Route path='/events/masks' element={<MasksPage />} />
    
    </Routes>
  );
};

export default App;
